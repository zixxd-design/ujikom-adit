# SISTEM INVENTORY - JUNIOR WEB DEVELOPER

Aplikasi CRUD inventory barang dengan PHP native dan MySQL.

## FITUR
- Registrasi dan Login user
- Dashboard dengan statistik (jumlah barang, total stok, total nilai)
- Data barang (CRUD: tambah, edit, hapus)
- Laporan inventory dengan cetak PDF
- Proteksi session dan CSRF token
- Mobile responsive dengan Bootstrap 5

## STRUKTUR FOLDER
```
inventory_system/
├── assets/
│   └── css/
│       └── style.css
├── fpdf/
│   └── (library FPDF)
├── includes/
│   ├── header.php
│   ├── footer.php
│   └── functions.php
├── config.php
├── database.sql
├── index.php
├── register.php
├── login.php
├── logout.php
├── dashboard.php
├── data_barang.php
├── laporan.php
└── cetak_pdf.php
```

## CARA INSTALASI

1. Install XAMPP (PHP 7.4+ dan MySQL)

2. Copy folder `inventory_system` ke `C:\xampp\htdocs\`

3. Jalankan XAMPP (Apache dan MySQL)

4. Buat database:
   - Buka phpMyAdmin: http://localhost/phpmyadmin
   - Import file `database.sql`

5. Konfigurasi database (jika perlu):
   - Edit file `config.php`
   - Sesuaikan DB_HOST, DB_USER, DB_PASS, DB_NAME

6. Akses aplikasi:
   - Buka browser: http://localhost/inventory_system
   - Daftar akun baru melalui halaman registrasi
   - Login dan mulai gunakan aplikasi

## KEAMANAN
- Password di-hash dengan password_hash()
- Prepared statement untuk query database
- CSRF token protection
- XSS protection dengan htmlspecialchars()
- Session-based authentication
- Input validation

## TEKNOLOGI
- PHP 7.4+ (native, tanpa framework)
- MySQL (database)
- Bootstrap 5 (CSS framework)
- FPDF (library PDF)

## CATATAN
- Tidak ada akun default, buat akun baru melalui registrasi
- Semua input divalidasi
- Error handling lengkap
- POST-Redirect-GET pattern untuk form submission
- Konfirmasi hapus menggunakan JavaScript
